var searchData=
[
  ['n_5f_0',['N_',['../class_discretisation.html#ae4f0cd489965186c9d4e24849aba2632',1,'Discretisation']]]
];
